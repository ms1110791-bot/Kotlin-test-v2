package com.example.settingshub

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val heading = TextView(this).apply {
            text = "SETTINGS HUB"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 20)
        }
        content.addView(heading)

        fun addSetting(title: String, action: String) {
            val button = Button(this).apply {
                text = title
                isAllCaps = false
                setOnClickListener {
                    try {
                        startActivity(Intent(action))
                    } catch (_: Exception) {
                        Toast.makeText(
                            this@MainActivity,
                            "यह सेटिंग इस फोन पर उपलब्ध नहीं है।",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            content.addView(
                button,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        addSetting("मुख्य सेटिंग", Settings.ACTION_SETTINGS)
        addSetting("Wi-Fi", Settings.ACTION_WIFI_SETTINGS)
        addSetting("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS)
        addSetting("Display", Settings.ACTION_DISPLAY_SETTINGS)
        addSetting("Sound", Settings.ACTION_SOUND_SETTINGS)
        addSetting("Location", Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        addSetting("Security", Settings.ACTION_SECURITY_SETTINGS)
        addSetting("Privacy", Settings.ACTION_PRIVACY_SETTINGS)
        addSetting("Apps", Settings.ACTION_APPLICATION_SETTINGS)
        addSetting("सभी इंस्टॉल किए गए ऐप्स", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
        addSetting("Notifications", Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        addSetting("Battery Saver", Settings.ACTION_BATTERY_SAVER_SETTINGS)
        addSetting("Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        addSetting("Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS)
        addSetting("Date and Time", Settings.ACTION_DATE_SETTINGS)
        addSetting("Language", Settings.ACTION_LOCALE_SETTINGS)
        addSetting("Developer Options", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        addSetting("Home Settings", Settings.ACTION_HOME_SETTINGS)

        val scrollView = ScrollView(this).apply {
            addView(content)
        }
        setContentView(scrollView)
    }
}
