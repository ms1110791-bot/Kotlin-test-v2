# Settings Hub Android App

एक छोटा Kotlin Android ऐप जो Android के उपलब्ध Settings पेज खोलता है।

## GitHub से APK बनाना

1. इस ZIP को extract करें।
2. इसकी सभी फाइलें अपनी GitHub repository के root में upload करें।
3. GitHub में **Actions** टैब खोलें।
4. **Build Settings Hub APK** workflow चुनें और **Run workflow** दबाएँ।
5. Build सफल होने पर workflow run के नीचे **Artifacts** में `SettingsHub-debug-apk` डाउनलोड करें।
6. ZIP खोलकर `app-debug.apk` इंस्टॉल करें।

यह debug APK है। इंस्टॉल करते समय Android अज्ञात स्रोत से इंस्टॉल करने की अनुमति पूछ सकता है।

## मुख्य Kotlin फाइल

`app/src/main/java/com/example/settingshub/MainActivity.kt`

## नोट

Android फोन निर्माता और Android संस्करण के अनुसार कुछ Settings पेज उपलब्ध न भी हों। ऐसे विकल्प पर ऐप संदेश दिखाएगा। ऐप को सिस्टम की प्रतिबंधित/छिपी सेटिंग्स तक विशेष पहुँच नहीं मिलती।
